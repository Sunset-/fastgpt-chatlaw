export enum EventNameEnum {
  guideClick = 'guideClick'
}
